abstract interface Game_interface {
    void step();

    String getInfo();
}