/*
Класс Интерфейс

Обучающийся: ШИТОВ Олег Владимирович, "Разработчик Python", поток 4544, будни, утро.  11.07.2023.
*/

import java.util.ArrayList;

abstract interface Game_interface {
    void step(ArrayList<Unit> unit);

    String getInfo();
}
