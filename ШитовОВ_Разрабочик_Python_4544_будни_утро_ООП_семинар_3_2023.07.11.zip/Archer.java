/*
Класс Лучник (Арбалетчик). Имеет предка: класс Стрелок.  Имеет доп. поле: число стрел.

Обучающийся: ШИТОВ Олег Владимирович, "Разработчик Python", поток 4544, будни, утро.  11.07.2023.
*/

class Archer extends Shooter {
    private int arrow;

    public Archer(String name, int health, int damage, int distance, int arrow, int x, int y) { // конструктор с 7-ю
                                                                                                // параметрами
        super(name, health, damage, distance, x, y);
        if (arrow < 0) {
            this.arrow = 0;
        } else if (arrow > 10) {
            this.arrow = 10;
        } else {
            this.arrow = arrow;
        }
    }

    public Archer() { // конструктор без параметров
        this("", 100, 0, 1, 10, 0, 0);
    } // конструктор без параметров

    public void attack() { // метод находится в работе
        System.out.println("Sniper " + name + " attacks with a shot.");
        arrow--;
    }
}
