/*
Класс Мог - наследник класса Заклинатель

Обучающийся: ШИТОВ Олег Владимирович, "Разработчик Python", поток 4544, будни, утро.  11.07.2023.
*/

class Magician extends Spirit {
    private int energy;

    public Magician(String name, int health, int energy, int x, int y) { // конструктор с 5-ю параметорами
        super(name, health, energy, x, y);
        if (energy < 0) {
            this.energy = 0;
        } else if (energy > 10) {
            this.energy = 10;
        } else {
            this.energy = energy;
        }
    }

    public Magician() { // конструктор без параметоров
        super("", 100, 10, 0, 0);
    }

    public void influence() {
        System.out.println("Magician " + name + " influences with magic.");
    } // метод находится в работе
}
