/*
Абстрактный класс пехота. Имеет предка: класс юнит. Имеет наследников: копейщик и разбойник. Имеет доп. поле: количество шагов.

Обучающийся: ШИТОВ Олег Владимирович, "Разработчик Python", поток 4544, будни, утро.  11.07.2023.
*/

import java.util.ArrayList;

abstract class Infantry extends Unit {
    private int step;

    public Infantry(String name, int health, int damage, int step, int x, int y) { // конструктор с 6-ю параметрами
        super(name, health, damage, x, y);
        if (step < 0) {
            this.step = 0;
        } else if (step > 100) {
            this.step = 10;
        } else {
            this.step = step;
        }
    }

    public Infantry() { // конструктор без параметров
        this("", 100, 0, 10, 0, 0);
    }

    public abstract void move();

    @Override
    public void step(ArrayList<Unit> unit) { // метод выводит ближайший персонаж с его координатами
        Unit tmp = nearest(unit);
        System.out.println(tmp.name + " " + coordinates.countDistance(tmp.coordinates));
    };
}
