/*Объектно-ориентированное программирование (семинары)

*Урок 1. Принципы ООП: Инкапсуляция, наследование, полиморфизм

Проанализировать и описать персонажей: Маг, Священник (или Монах), Разбойник, Копейщик, Снайпер, Лучник (или Арбалетчик), Крестьянин.
На базе описания персонажей описать простейшую иерархию классов.
В основной программе создать по одному экземпляру каждого класса.

*Урок 2. Принципы ООП Абстракция и интерфейсы. Пример проектирования

Добавить файл с описанием интерфейса. В котором описать два метода, void step(); и String getInfo();
Реализовать интерфейс в абстрактном классе и в наследниках так, чтобы getInfo возвращал тип персонажа.
Создать два списка в классе main. В каждый из списков добавить по десять случайных экземнляров наследников BaseHero.
Удалить ненужные методы из абстрактного класса, если такие есть.
В main пройти по спискам и вызвать у всех персонажей getInfo.

*Урок 3. Некоторые стандартные интерфейсы Java и примеры их использования

Создать класс с описанием координат, x и y.
Добавить в абстрактный класс поле с координатами и пробросить его инициализацию до конструкторов персонажей:
    Farmer farmer = new Farmer(getName(), x, y);
Найти среди противников ближайшего и вывести расстояние до него и его имя в консоль.

Обучающийся: ШИТОВ Олег Владимирович, "Разработчик Python", поток 4544, будни, утро.  11.07.2023.
 */

import com.sun.source.util.SourcePositions;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Random;

public class Role_game { // основной модуль

    public static void main(String[] args) {

        final int TEAM_SIZE = 10; // в обеих командах будет по 10 персонажей

        System.out.println("**** Команда1: ****");
        ArrayList<Unit> team1 = team(TEAM_SIZE, 0); // создаём команду1

        System.out.println("\n**** Команда2: ****");
        ArrayList<Unit> team2 = team(TEAM_SIZE, 10); // создаём команду2

        System.out.println("\n**** Distance to the nearest enemy: ****");
        team1.forEach(n -> n.step(team2)); // ближайший соперник

    }

    public static ArrayList<Unit> team(int teamSize, int num) { // метод создаёт команду из числа <teamSize> случайно
                                                                // выбранных персонажей
        ArrayList<Unit> team = new ArrayList<>();

        System.out.println(num);

        for (int i = 0; i < teamSize; i++) {
            int val = new Random().nextInt(7);
            switch (val) {
                case (0):
                    team.add(new Magician("Magician", 100, 0, num, 0));
                    break;
                case (1):
                    team.add(new Priest("Priest", 100, 0, 0, num, 1));
                    break;
                case (2):
                    team.add(new Robber("Robber", 100, 0, 0, num, 2));
                    break;
                case (3):
                    team.add(new Spearman("Spearman", 100, 0, 0, num, 3));
                    break;
                case (4):
                    team.add(new Sniper("Sniper", 100, 0, 0, 10, num, 4));
                    break;
                case (5):
                    team.add(new Archer("Archer", 100, 0, 0, 0, num, 5));
                    break;
                default:
                    team.add(new Peasant("Peasant", 100, 0, num, 6));
                    break;
            }
            System.out.printf("%d) %s\n", i, team.get(i).getInfo());
        }
        return team;
    }
}
/*
 **** Команда1: ****
 * 0
 * 0) Magician Маша x=0 y=0
 * 1) Archer Маша x=0 y=5
 * 2) Priest Вова x=0 y=1
 * 3) Robber Витя x=0 y=2
 * 4) Priest Вова x=0 y=1
 * 5) Peasant Оля x=0 y=6
 * 6) Sniper Галя x=0 y=4
 * 7) Spearman Лена x=0 y=3
 * 8) Peasant Боря x=0 y=6
 * 9) Magician Галя x=0 y=0
 **** 
 * Команда2: ****
 * 10
 * 0) Priest Вова x=10 y=1
 * 1) Priest Виталик x=10 y=1
 * 2) Magician Саша x=10 y=0
 * 3) Robber Маша x=10 y=2
 * 4) Sniper Лена x=10 y=4
 * 5) Robber Галя x=10 y=2
 * 6) Priest Галя x=10 y=1
 * 7) Spearman Галя x=10 y=3
 * 8) Magician Виталик x=10 y=0
 * 9) Magician Галя x=10 y=0
 **** 
 * Distance to the nearest enemy: ****
 * Robber 10.0
 * Spearman 10.0
 */