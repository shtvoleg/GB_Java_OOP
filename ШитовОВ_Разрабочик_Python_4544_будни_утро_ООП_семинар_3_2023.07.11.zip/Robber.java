/*
Класс разбойник. Имеет предка: класс пехота.

Обучающийся: ШИТОВ Олег Владимирович, "Разработчик Python", поток 4544, будни, утро.  11.07.2023.
*/

import java.util.ArrayList;

class Robber extends Infantry {
    private int power;

    public Robber(String name, int health, int damage, int power, int x, int y) { // конструктор с 6-ю параметрами
        super(name, health, damage, power, x, y);
        if (power < 0) {
            this.power = 0;
        } else if (power > 10) {
            this.power = 10;
        } else {
            this.power = power;
        }
    }

    public Robber() { // конструктор без параметров
        this("", 100, 0, 10, 0, 0);
    } // констрактор без параметров

    public void move() {
        System.out.println("Robber " + name + " moves.");
    } // метода находится в работе

    @Override
    public void step(ArrayList<Unit> unit) {
        Unit tmp = nearest(unit);
        System.out.println(tmp.name + " " + coordinates.countDistance(tmp.coordinates));
    }
}