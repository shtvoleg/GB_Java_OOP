/*
Класс Священник - наследник класса Заклинатель

Обучающийся: ШИТОВ Олег Владимирович, "Разработчик Python", поток 4544, будни, утро.  11.07.2023.
*/

class Priest extends Spirit {
    private int elixir;

    public Priest(String name, int health, int damage, int elixir, int x, int y) { // конструктор с 6-ю параметрами
        super(name, health, damage, x, y);
        if (elixir < 0) {
            this.elixir = 0;
        } else if (elixir > 10) {
            this.elixir = 10;
        } else {
            this.elixir = elixir;
        }
    }

    public void influence() {
        System.out.println("Priest " + name + " influences with prayers.");
    } // метод находится в работе
}
