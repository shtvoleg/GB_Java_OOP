/*
Абстрактный класс стрелок. Имеет предка: класс юнит. Имеет наследников: снайпер и лучник (арбалетчик). Имеет доп. поле: дистанция стрельбы.

Обучающийся: ШИТОВ Олег Владимирович, "Разработчик Python", поток 4544, будни, утро.  11.07.2023.
*/
abstract class Shooter extends Unit {
    protected int distance; // дистанция стрельбы

    public Shooter(String name, int health, int damage, int distance, int x, int y) { // конструктор с 6-ю параметрами
        super(name, health, damage, x, y);
        if (distance < 0) {
            this.distance = 0;
        } else if (distance > 10) {
            this.distance = 10;
        } else {
            this.distance = distance;
        }
    }

    public Shooter() { // конструктор без параметров
        this("", 100, 0, 1, 0, 0);
    } // конструктор без параметров

    public abstract void attack();
}
